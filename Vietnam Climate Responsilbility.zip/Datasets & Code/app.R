
library(readxl)
library(shiny)
library(tidyverse)
library(plotly)
library(sf)
library(rnaturalearth)
library(rnaturalearthdata)

# ── Load data ──────────────────────────────────────────────────────────────────
ghg_data <- read_excel("merged_5yr_mean.xlsx")
carbon_data  <- read_excel("final_cleaned_merged_5yr.xlsx")

carbon_data <- carbon_data %>%
  rename(
    Entity       = country,
    Period       = period,
    co2_total    = `annual co2‚ emissions`,
    co2_pc       = `co2‚ emissions per capita`,
    gdp_pc       = `gdp per capita`,
    share_global = `share of global annual co2‚ emissions`
  ) %>%
  mutate(Period = factor(Period, levels = sort(unique(Period))))

ghg_data <- ghg_data %>%
  rename(
    Entity   = country,
    prod_ghg = `Annual greenhouse gas emissions in CO2 equivalents`,
    cons_ghg = `Annual consumption-based CO2 equivalents`,
    ghg_pc   = `Per capita greenhouse gas emissions in CO2 equivalents`
  ) %>%
  mutate(
    Period             = factor(Period, levels = sort(unique(Period))),
    Responsibility_Gap = cons_ghg - prod_ghg
  )

ghg_sector_long <- ghg_data %>%
  pivot_longer(
    cols = c(
      `Greenhouse gas emissions from agriculture`,
      `Greenhouse gas emissions from land-use change and forestry`,
      `Greenhouse gas emissions from waste`,
      `Greenhouse gas emissions from buildings`,
      `Greenhouse gas emissions from industry`,
      `Greenhouse gas emissions from manufacturing and construction`,
      `Greenhouse gas emissions from transport`,
      `Greenhouse gas emissions from electricity and heat`,
      `Fugitive emissions of greenhouse gases from energy production`,
      `Greenhouse gas emissions from other fuel combustion`
    ),
    names_to  = "Sector",
    values_to = "Emissions"
  ) %>%
  filter(!is.na(Emissions))

world_map <- ne_countries(scale = "medium", returnclass = "sf")
# Clean continent + international transport entities
CONTINENT_ENTITIES <- c(
  "Africa", "Asia", "Europe",
  "North America", "South America", "Oceania",
  "International aviation", "International shipping"
)




# Country-to-continent lookup (countries only, no regional aggregates)
country_continent_map <- list(
  "Africa"         = c("Algeria","Angola","Benin","Botswana","Burkina Faso",
                       "Burundi","Cameroon","Cape Verde","Central African Republic",
                       "Chad","Comoros","Congo","Cote d'Ivoire",
                       "Democratic Republic of Congo","Djibouti","Egypt",
                       "Equatorial Guinea","Eritrea","Eswatini","Ethiopia",
                       "Gabon","Gambia","Ghana","Guinea","Guinea-Bissau",
                       "Kenya","Lesotho","Liberia","Libya","Madagascar",
                       "Malawi","Mali","Mauritania","Mauritius","Morocco",
                       "Mozambique","Namibia","Niger","Nigeria","Rwanda",
                       "Sao Tome and Principe","Senegal","Seychelles",
                       "Sierra Leone","Somalia","South Africa","South Sudan",
                       "Sudan","Tanzania","Togo","Tunisia","Uganda",
                       "Zambia","Zimbabwe"),
  "Asia"           = c("Afghanistan","Armenia","Azerbaijan","Bahrain",
                       "Bangladesh","Bhutan","Brunei","Cambodia","China",
                       "Cyprus","Georgia","Hong Kong","India","Indonesia",
                       "Iran","Iraq","Israel","Japan","Jordan","Kazakhstan",
                       "Kuwait","Kyrgyzstan","Laos","Lebanon","Macao",
                       "Malaysia","Maldives","Mongolia","Myanmar","Nepal",
                       "North Korea","Oman","Pakistan","Palestine","Philippines",
                       "Qatar","Russia","Saudi Arabia","Singapore","South Korea",
                       "Sri Lanka","Syria","Taiwan","Tajikistan","Thailand",
                       "Timor-Leste","Turkey","Turkmenistan","United Arab Emirates",
                       "Uzbekistan","Vietnam","Yemen"),
  "Europe"         = c("Albania","Andorra","Austria","Belarus","Belgium",
                       "Bosnia and Herzegovina","Bulgaria","Croatia","Czechia",
                       "Denmark","Estonia","Finland","France","Germany",
                       "Greece","Hungary","Iceland","Ireland","Italy",
                       "Kosovo","Latvia","Liechtenstein","Lithuania","Luxembourg",
                       "Malta","Moldova","Montenegro","Netherlands","North Macedonia",
                       "Norway","Poland","Portugal","Romania","San Marino",
                       "Serbia","Slovakia","Slovenia","Spain","Sweden",
                       "Switzerland","Ukraine","United Kingdom"),
  "North America"  = c("Antigua and Barbuda","Bahamas","Barbados","Belize",
                       "Canada","Costa Rica","Cuba","Dominica","Dominican Republic",
                       "El Salvador","Grenada","Guatemala","Haiti","Honduras",
                       "Jamaica","Mexico","Nicaragua","Panama","Puerto Rico",
                       "Saint Kitts and Nevis","Saint Lucia",
                       "Saint Vincent and the Grenadines","Trinidad and Tobago",
                       "United States"),
  "South America"  = c("Argentina","Bolivia","Brazil","Chile","Colombia",
                       "Ecuador","Guyana","Paraguay","Peru","Suriname",
                       "Uruguay","Venezuela"),
  "Oceania"        = c("Australia","Fiji","Kiribati","Marshall Islands",
                       "Micronesia (country)","Nauru","New Zealand",
                       "Papua New Guinea","Samoa","Solomon Islands",
                       "Tonga","Tuvalu","Vanuatu")
)



# ── UI ─────────────────────────────────────────────────────────────
ui <- fluidPage(
  
  tags$head(tags$style(HTML("
    body { background-color:#f0f2f5; font-family:'Segoe UI'; }
    .sidebar { background-color:#2c3e50 !important; color:white; }
    .sidebar .control-label { color:#ecf0f1; font-weight:bold; }
    .sidebar .selectize-input,
    .sidebar .form-control { background-color:#34495e; color:white; border:none; }
    .sidebar .radio label  { color:#ecf0f1; }
    .panel-box {
      background:white; padding:15px;
      border-radius:12px;
      box-shadow:0px 3px 8px rgba(0,0,0,0.2);
    }
    .panel-title {
      font-size:18px; font-weight:bold;
      color:white; padding:10px; border-radius:8px;
    }
    .blue   { background:#1f77b4; }
    .red    { background:#d62728; }
    .green  { background:#2ca02c; }
    .purple { background:#9467bd; }
    .subtitle { color:#555; margin:10px 0 15px 0; }
    .nav-tabs > li > a {
      background-color:#34495e; color:white;
      border-radius:8px; margin-right:5px;
    }
    .nav-tabs > li > a:hover { background-color:#1abc9c; color:white; }
    .nav-tabs > li.active > a {
      background-color:#e74c3c !important;
      color:white !important; font-weight:bold;
    }
    .plotly-output { height:600px !important; }

      /* ══════════════════════════════════════════
         COVER PAGE STYLES — PASTE LOCATION 1
      ══════════════════════════════════════════ */
      @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Exo+2:wght@300;400;600&display=swap');

      #cover-page {
        position:fixed; top:0; left:0;
        width:100vw; height:100vh;
        z-index:9999;
        display:flex; flex-direction:column;
        align-items:center; justify-content:center;
        overflow:hidden; background:#030d1a;
        transition:opacity 1s cubic-bezier(0.4,0,0.2,1),
                   transform 1s cubic-bezier(0.4,0,0.2,1);
      }
      #cover-page.hidden {
        opacity:0; pointer-events:none; transform:scale(1.04);
      }
      #cover-bg-grad {
        position:absolute; inset:0;
        background:
          radial-gradient(ellipse 80% 60% at 15% 40%,
            rgba(0,40,20,0.55) 0%, transparent 65%),
          radial-gradient(ellipse 60% 80% at 85% 70%,
            rgba(0,20,60,0.5) 0%, transparent 65%),
          radial-gradient(ellipse 100% 100% at 50% 50%,
            #030d1a 0%, #010810 100%);
      }
      #cover-grid {
        position:absolute; inset:0;
        background-image:
          linear-gradient(rgba(0,200,120,0.025) 1px, transparent 1px),
          linear-gradient(90deg, rgba(0,200,120,0.025) 1px, transparent 1px);
        background-size:55px 55px;
        animation:gridDrift 25s linear infinite;
      }
      @keyframes gridDrift {
        from { background-position:0 0; }
        to   { background-position:55px 55px; }
      }
      #cover-canvas {
        position:absolute; inset:0; width:100%; height:100%;
      }
      .c-orb {
        position:absolute; border-radius:50%;
        filter:blur(90px); pointer-events:none;
        animation:orbPulse ease-in-out infinite;
      }
      .c-orb-1 {
        width:500px; height:500px;
        background:radial-gradient(circle, rgba(0,180,100,0.12), transparent 70%);
        top:-120px; left:-80px;
        animation-duration:22s;
      }
      .c-orb-2 {
        width:400px; height:400px;
        background:radial-gradient(circle, rgba(0,80,200,0.1), transparent 70%);
        bottom:-60px; right:-60px;
        animation-duration:28s; animation-delay:-8s;
      }
      .c-orb-3 {
        width:250px; height:250px;
        background:radial-gradient(circle, rgba(220,60,20,0.09), transparent 70%);
        top:35%; right:12%;
        animation-duration:18s; animation-delay:-4s;
      }
      @keyframes orbPulse {
        0%,100% { transform:scale(1) translate(0,0); }
        33%      { transform:scale(1.08) translate(15px,-10px); }
        66%      { transform:scale(0.94) translate(-10px,20px); }
      }
      .c-wave-wrap {
        position:absolute; bottom:0; left:0;
        width:100%; height:130px; overflow:hidden;
      }
      .c-wave { position:absolute; bottom:0; width:200%; height:100%; }
      .c-wave-a { animation:waveScroll 10s linear infinite; opacity:0.25; }
      .c-wave-b { animation:waveScroll 16s linear infinite reverse; opacity:0.12; }
      @keyframes waveScroll {
        from { transform:translateX(0); }
        to   { transform:translateX(-50%); }
      }
      .c-content {
        position:relative; z-index:10;
        text-align:center;
        width:min(1150px, 94vw);
        padding:0 24px;
      }
      .c-eyebrow {
        font-family:'Orbitron', monospace;
        font-size:10px; letter-spacing:7px;
        color:#00c87a; text-transform:uppercase;
        margin-bottom:14px;
        opacity:0; animation:riseIn 0.7s ease 0.15s forwards;
      }
      .c-title {
        font-family:'Orbitron', monospace;
        font-size:clamp(24px,3.8vw,50px);
        font-weight:900; color:#fff;
        line-height:1.12; margin-bottom:6px;
        opacity:0; animation:riseIn 0.7s ease 0.35s forwards;
      }
      .c-title-accent {
        background:linear-gradient(130deg,#00c87a 0%,#00aaff 100%);
        -webkit-background-clip:text;
        -webkit-text-fill-color:transparent;
        background-clip:text;
      }
      .c-sub {
        font-family:'Exo 2', sans-serif;
        font-size:13px; color:rgba(255,255,255,0.38);
        letter-spacing:2px; margin-bottom:36px;
        opacity:0; animation:riseIn 0.7s ease 0.55s forwards;
      }
      .c-glance-label {
        font-family:'Exo 2', sans-serif;
        font-size:10px; letter-spacing:5px;
        color:rgba(255,255,255,0.22); text-transform:uppercase;
        margin-bottom:18px;
        opacity:0; animation:riseIn 0.7s ease 0.68s forwards;
      }
      .c-kpi-grid {
        display:grid; grid-template-columns:repeat(5,1fr);
        gap:14px; margin-bottom:40px;
        opacity:0; animation:riseIn 0.8s ease 0.82s forwards;
      }
      .c-kpi {
        background:rgba(255,255,255,0.035);
        border:1px solid rgba(255,255,255,0.07);
        border-radius:18px; padding:22px 12px 18px;
        position:relative; overflow:hidden; cursor:default;
        transition:transform 0.28s ease, background 0.28s ease,
                   border-color 0.28s ease, box-shadow 0.28s ease;
      }
      .c-kpi::after {
        content:''; position:absolute; inset:0;
        border-radius:18px; opacity:0; transition:opacity 0.28s ease;
      }
      .c-kpi:hover {
        transform:translateY(-6px);
        background:rgba(255,255,255,0.07);
        border-color:rgba(255,255,255,0.18);
        box-shadow:0 20px 50px rgba(0,0,0,0.5);
      }
      .c-kpi:hover::after { opacity:1; }
      .c-kpi::before {
        content:''; position:absolute;
        top:0; left:0; right:0;
        height:2.5px; border-radius:18px 18px 0 0;
      }
      .c-kpi:nth-child(1)::before { background:linear-gradient(90deg,#00c87a,#00aaff); }
      .c-kpi:nth-child(1)::after  { background:linear-gradient(160deg,rgba(0,200,122,0.06),transparent); }
      .c-kpi:nth-child(2)::before { background:linear-gradient(90deg,#ff6b35,#ffb800); }
      .c-kpi:nth-child(2)::after  { background:linear-gradient(160deg,rgba(255,107,53,0.06),transparent); }
      .c-kpi:nth-child(3)::before { background:linear-gradient(90deg,#e74c3c,#9b2335); }
      .c-kpi:nth-child(3)::after  { background:linear-gradient(160deg,rgba(231,76,60,0.06),transparent); }
      .c-kpi:nth-child(4)::before { background:linear-gradient(90deg,#9b59b6,#6c3483); }
      .c-kpi:nth-child(4)::after  { background:linear-gradient(160deg,rgba(155,89,182,0.06),transparent); }
      .c-kpi:nth-child(5)::before { background:linear-gradient(90deg,#00aaff,#0055cc); }
      .c-kpi:nth-child(5)::after  { background:linear-gradient(160deg,rgba(0,170,255,0.06),transparent); }
      .c-kpi-icon {
        font-size:22px; margin-bottom:10px; display:block; line-height:1;
      }
      .c-kpi-val {
        font-family:'Orbitron', monospace;
        font-size:clamp(14px,1.7vw,20px);
        font-weight:700; color:#fff;
        line-height:1; margin-bottom:4px; white-space:nowrap;
      }
      .c-kpi-delta {
        font-family:'Exo 2', sans-serif;
        font-size:10px; font-weight:600;
        margin-bottom:6px; display:inline-block;
        padding:2px 7px; border-radius:20px;
      }
      .delta-bad  { color:#ff6b6b; background:rgba(255,107,107,0.12); }
      .delta-warn { color:#ffb800; background:rgba(255,184,0,0.12); }
      .delta-good { color:#00c87a; background:rgba(0,200,122,0.12); }
      .c-kpi-label {
        font-family:'Exo 2', sans-serif;
        font-size:9.5px; color:rgba(255,255,255,0.38);
        text-transform:uppercase; letter-spacing:1px; line-height:1.4;
      }
      .c-kpi-tab {
        font-family:'Exo 2', sans-serif;
        font-size:8px; color:rgba(255,255,255,0.2);
        text-transform:uppercase; letter-spacing:1.5px;
        margin-top:8px; display:block;
      }
      .c-btn-wrap {
        opacity:0; animation:riseIn 0.7s ease 1.25s forwards;
      }
      #c-enter-btn {
        font-family:'Orbitron', monospace;
        font-size:11px; font-weight:700;
        letter-spacing:5px; text-transform:uppercase;
        color:#fff; background:transparent;
        border:1.5px solid rgba(0,200,122,0.5);
        padding:15px 52px; border-radius:60px;
        cursor:pointer; position:relative; overflow:hidden;
        transition:all 0.35s ease;
        box-shadow:0 0 35px rgba(0,200,122,0.12),
                   inset 0 0 25px rgba(0,200,122,0.04);
      }
      #c-enter-btn::before {
        content:''; position:absolute; inset:0;
        background:linear-gradient(135deg,
          rgba(0,200,122,0.18), rgba(0,170,255,0.18));
        opacity:0; transition:opacity 0.35s ease;
      }
      #c-enter-btn:hover {
        border-color:#00c87a;
        box-shadow:0 0 70px rgba(0,200,122,0.3),
                   inset 0 0 30px rgba(0,200,122,0.08);
        transform:scale(1.05);
      }
      #c-enter-btn:hover::before { opacity:1; }
      .c-arrow {
        display:inline-block; margin-left:10px;
        transition:transform 0.3s ease;
      }
      #c-enter-btn:hover .c-arrow { transform:translateX(7px); }
      .c-tags {
        position:absolute; bottom:145px;
        left:50%; transform:translateX(-50%);
        display:flex; gap:10px; flex-wrap:wrap;
        justify-content:center;
        opacity:0; animation:riseIn 0.7s ease 1.45s forwards;
      }
      .c-tag {
        font-family:'Exo 2', sans-serif;
        font-size:9px; color:rgba(255,255,255,0.25);
        letter-spacing:2px; text-transform:uppercase;
        padding:4px 12px;
        border:1px solid rgba(255,255,255,0.07);
        border-radius:20px; white-space:nowrap;
      }
     

      @keyframes riseIn {
        from { opacity:0; transform:translateY(18px); }
        to   { opacity:1; transform:translateY(0); }
      }
    ")),
            tags$style(HTML("
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Exo+2:wght@300;400;600&display=swap');

    /* ── GLOBAL BODY ── */
    body {
      background: #030d1a;
      background-image:
        radial-gradient(ellipse 80% 60% at 15% 40%,
          rgba(0,40,20,0.4) 0%, transparent 60%),
        radial-gradient(ellipse 60% 80% at 85% 70%,
          rgba(0,20,60,0.35) 0%, transparent 60%);
      background-attachment: fixed;
      font-family: 'Exo 2', 'Segoe UI', sans-serif;
      color: #e8eaf0;
      min-height: 100vh;
    }

    /* Animated grid overlay on body */
    body::before {
      content: '';
      position: fixed;
      inset: 0;
      background-image:
        linear-gradient(rgba(0,200,120,0.018) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,200,120,0.018) 1px, transparent 1px);
      background-size: 55px 55px;
      pointer-events: none;
      z-index: 0;
    }

    /* ── TITLE PANEL ── */
    .container-fluid > h2,
    h2.shiny-title {
      font-family: 'Orbitron', monospace !important;
      font-size: clamp(14px, 1.6vw, 22px) !important;
      font-weight: 700 !important;
      color: #ffffff !important;
      letter-spacing: 3px;
      text-transform: uppercase;
      padding: 18px 0 14px 0;
      background: transparent;
      border-bottom: 1px solid rgba(0,200,122,0.2);
      margin-bottom: 16px;
    }

    /* ── LAYOUT WRAPPER ── */
    .container-fluid { position: relative; z-index: 1; }

    /* ── SIDEBAR ── */
    .well, .sidebar {
      background: rgba(255,255,255,0.04) !important;
      border: 1px solid rgba(0,200,122,0.15) !important;
      border-radius: 16px !important;
      box-shadow:
        0 8px 32px rgba(0,0,0,0.4),
        inset 0 0 0 1px rgba(255,255,255,0.04) !important;
      backdrop-filter: blur(12px);
      padding: 20px 16px !important;
    }

    /* Sidebar labels */
    .sidebar .control-label,
    .well .control-label {
      font-family: 'Exo 2', sans-serif !important;
      color: rgba(0,200,122,0.9) !important;
      font-size: 11px !important;
      font-weight: 600 !important;
      letter-spacing: 2px !important;
      text-transform: uppercase !important;
      margin-bottom: 6px !important;
    }

    /* Sidebar inputs */
    .sidebar .selectize-input,
    .sidebar .form-control,
    .well .selectize-input,
    .well .form-control {
      background: rgba(255,255,255,0.06) !important;
      border: 1px solid rgba(0,200,122,0.2) !important;
      border-radius: 8px !important;
      color: #ffffff !important;
      font-family: 'Exo 2', sans-serif !important;
      font-size: 12px !important;
    }

    .sidebar .selectize-input:focus,
    .well .selectize-input:focus {
      border-color: rgba(0,200,122,0.6) !important;
      box-shadow: 0 0 12px rgba(0,200,122,0.15) !important;
    }

    /* Selectize dropdown */
    .selectize-dropdown {
      background: #0d1f35 !important;
      border: 1px solid rgba(0,200,122,0.25) !important;
      border-radius: 8px !important;
      color: #e8eaf0 !important;
    }
    .selectize-dropdown .option:hover,
    .selectize-dropdown .option.active {
      background: rgba(0,200,122,0.15) !important;
      color: #ffffff !important;
    }

    /* Radio buttons */
    .sidebar .radio label,
    .well .radio label,
    .radio label {
      color: rgba(255,255,255,0.75) !important;
      font-family: 'Exo 2', sans-serif !important;
      font-size: 12px !important;
    }

    input[type='radio']:checked + span,
    input[type='radio']:checked ~ span {
      color: #00c87a !important;
    }

    /* Slider */
    .irs--shiny .irs-bar,
    .irs-bar { background: #00c87a !important; }
    .irs--shiny .irs-handle,
    .irs-handle { border-color: #00c87a !important; }
    .irs--shiny .irs-from,
    .irs--shiny .irs-to,
    .irs--shiny .irs-single {
      background: #00c87a !important;
      font-family: 'Exo 2', sans-serif !important;
    }

    /* Numeric input */
    input[type='number'] {
      background: rgba(255,255,255,0.06) !important;
      border: 1px solid rgba(0,200,122,0.2) !important;
      border-radius: 8px !important;
      color: #ffffff !important;
      font-family: 'Exo 2', sans-serif !important;
    }

    /* ── ACTION BUTTON ── */
    .btn, .action-button {
      background: rgba(0,200,122,0.12) !important;
      border: 1px solid rgba(0,200,122,0.4) !important;
      border-radius: 8px !important;
      color: #00c87a !important;
      font-family: 'Exo 2', sans-serif !important;
      font-size: 11px !important;
      letter-spacing: 2px !important;
      text-transform: uppercase !important;
      transition: all 0.3s ease !important;
    }
    .btn:hover, .action-button:hover {
      background: rgba(0,200,122,0.25) !important;
      border-color: #00c87a !important;
      box-shadow: 0 0 20px rgba(0,200,122,0.25) !important;
      color: #ffffff !important;
    }

    /* ── TABS ── */
    .nav-tabs {
      border-bottom: 1px solid rgba(0,200,122,0.15) !important;
      margin-bottom: 0 !important;
    }

    .nav-tabs > li > a {
      background: rgba(255,255,255,0.03) !important;
      border: 1px solid rgba(255,255,255,0.07) !important;
      border-radius: 10px 10px 0 0 !important;
      color: rgba(255,255,255,0.5) !important;
      font-family: 'Exo 2', sans-serif !important;
      font-size: 11px !important;
      font-weight: 600 !important;
      letter-spacing: 1.5px !important;
      text-transform: uppercase !important;
      margin-right: 4px !important;
      padding: 8px 14px !important;
      transition: all 0.25s ease !important;
    }

    .nav-tabs > li > a:hover {
      background: rgba(0,200,122,0.1) !important;
      border-color: rgba(0,200,122,0.3) !important;
      color: #00c87a !important;
      box-shadow: 0 0 14px rgba(0,200,122,0.1) !important;
    }

    .nav-tabs > li.active > a,
    .nav-tabs > li.active > a:focus,
    .nav-tabs > li.active > a:hover {
      background: rgba(0,200,122,0.15) !important;
      border-color: rgba(0,200,122,0.5) !important;
      border-bottom-color: transparent !important;
      color: #00c87a !important;
      font-weight: 700 !important;
      box-shadow: 0 0 20px rgba(0,200,122,0.2),
                  inset 0 0 12px rgba(0,200,122,0.06) !important;
    }

    /* ── PANEL TITLE BARS ── */
    .panel-title {
      font-family: 'Orbitron', monospace !important;
      font-size: 13px !important;
      font-weight: 700 !important;
      letter-spacing: 3px !important;
      text-transform: uppercase !important;
      color: #ffffff !important;
      padding: 12px 16px !important;
      border-radius: 10px 10px 0 0 !important;
      margin-bottom: 0 !important;
      position: relative;
      overflow: hidden;
    }

    .panel-title::after {
      content: '';
      position: absolute;
      bottom: 0; left: 0; right: 0;
      height: 1px;
      background: linear-gradient(90deg,
        transparent, rgba(255,255,255,0.3), transparent);
    }

    .blue, .red, .green, .purple {
      background: linear-gradient(135deg,
        rgba(0,60,35,0.95), rgba(0,40,22,0.9)) !important;
      border: 1px solid rgba(0,200,122,0.25) !important;
      box-shadow: 0 0 18px rgba(0,130,70,0.15) !important;
    }

    /* ── GLASS PANEL BOX ── */
    .panel-box {
      background: rgba(255,255,255,0.03) !important;
      border: 1px solid rgba(255,255,255,0.08) !important;
      border-top: none !important;
      border-radius: 0 0 14px 14px !important;
      box-shadow:
        0 16px 48px rgba(0,0,0,0.5),
        inset 0 0 0 1px rgba(255,255,255,0.03) !important;
      backdrop-filter: blur(16px) !important;
      padding: 20px !important;
    }

    /* ── PLOTLY CHART BACKGROUNDS ── */
    .plotly, .js-plotly-plot {
      background: transparent !important;
      border-radius: 10px !important;
    }

    /* ── HR DIVIDERS ── */
    hr {
      border-color: rgba(0,200,122,0.15) !important;
      margin: 12px 0 !important;
    }

    /* ── INLINE RADIO GROUP (ts_view toggle) ── */
    .radio-inline, .shiny-input-radiogroup .radio-inline {
      color: rgba(255,255,255,0.6) !important;
      font-family: 'Exo 2', sans-serif !important;
      font-size: 11px !important;
      letter-spacing: 1.5px !important;
      text-transform: uppercase !important;
    }

    /* ── OUTLIER + EFFICIENCY CARD BOXES ── */
    [style*='background:#e8f5e9'],
    [style*='background:#ffebee'],
    [style*='background:#e3f2fd'],
    [style*='background:#fff3e0'],
    [style*='background:#fce4ec'],
    [style*='background:#e8f5e9;'],
    [style*='background:#ffebee;'],
    [style*='background:#e3f2fd;'],
    [style*='background:#fff3e0;'],
    [style*='background:#fce4ec;'] {
      background: rgba(255,255,255,0.04) !important;
      border-radius: 10px !important;
      color: #e8eaf0 !important;
    }

    /* ── SCROLLBAR ── */
    ::-webkit-scrollbar { width: 6px; height: 6px; }
    ::-webkit-scrollbar-track { background: rgba(255,255,255,0.03); }
    ::-webkit-scrollbar-thumb {
      background: rgba(0,200,122,0.3);
      border-radius: 10px;
    }
    ::-webkit-scrollbar-thumb:hover {
      background: rgba(0,200,122,0.6);
    }

    /* ── uiOutput text inside cards ── */
    .shiny-html-output p,
    .shiny-html-output li,
    .shiny-html-output ul {
      color: rgba(255,255,255,0.75) !important;
      font-family: 'Exo 2', sans-serif !important;
    }

    /* ── fluidRow column text ── */
    .col-sm-3 b, .col-sm-4 b {
      color: rgba(255,255,255,0.9) !important;
      font-family: 'Exo 2', sans-serif !important;
      font-size: 11px !important;
      letter-spacing: 1px !important;
      text-transform: uppercase !important;
    }

    /* ── COVER PAGE (keep unchanged) ── */
    #cover-page { z-index: 9999 !important; }
  ")),
            
            
            # PASTE LOCATION 2 — JavaScript (paste this right after the CSS closing "))," above)
            tags$script(HTML("
      document.addEventListener('DOMContentLoaded', function() {

        /* Particle network */
        var canvas = document.getElementById('cover-canvas');
        if (!canvas) return;
        var ctx = canvas.getContext('2d');
        function resize() {
          canvas.width  = window.innerWidth;
          canvas.height = window.innerHeight;
        }
        resize();
        window.addEventListener('resize', resize);

        var pts = [];
        for (var i = 0; i < 130; i++) {
          pts.push({
            x:  Math.random() * window.innerWidth,
            y:  Math.random() * window.innerHeight,
            r:  Math.random() * 1.6 + 0.3,
            dx: (Math.random() - 0.5) * 0.35,
            dy: (Math.random() - 0.5) * 0.35,
            a:  Math.random() * 0.55 + 0.1,
            c:  Math.random() > 0.65 ? '0,200,122' :
                Math.random() > 0.45 ? '0,170,255' : '255,255,255'
          });
        }

        function draw() {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          for (var i = 0; i < pts.length; i++) {
            for (var j = i+1; j < pts.length; j++) {
              var ddx = pts[i].x-pts[j].x, ddy = pts[i].y-pts[j].y;
              var d   = Math.sqrt(ddx*ddx+ddy*ddy);
              if (d < 130) {
                ctx.beginPath();
                ctx.strokeStyle = 'rgba(0,200,122,'+(0.07*(1-d/130))+')';
                ctx.lineWidth   = 0.5;
                ctx.moveTo(pts[i].x, pts[i].y);
                ctx.lineTo(pts[j].x, pts[j].y);
                ctx.stroke();
              }
            }
            ctx.beginPath();
            ctx.arc(pts[i].x, pts[i].y, pts[i].r, 0, Math.PI*2);
            ctx.fillStyle = 'rgba('+pts[i].c+','+pts[i].a+')';
            ctx.fill();
            pts[i].x += pts[i].dx; pts[i].y += pts[i].dy;
            if (pts[i].x<0||pts[i].x>canvas.width)  pts[i].dx*=-1;
            if (pts[i].y<0||pts[i].y>canvas.height) pts[i].dy*=-1;
          }
          requestAnimationFrame(draw);
        }
        draw();

        /* Counter animation */
        function counter(id, from, to, suffix, dec, ms) {
          var el = document.getElementById(id);
          if (!el) return;
          var t0 = null;
          function step(ts) {
            if (!t0) t0 = ts;
            var p = Math.min((ts-t0)/ms, 1);
            var e = 1 - Math.pow(1-p, 3);
            el.textContent = (from + (to-from)*e).toFixed(dec) + suffix;
            if (p < 1) requestAnimationFrame(step);
          }
          requestAnimationFrame(step);
        }
        setTimeout(function() {
          counter('kv-1', 0, 343.6, ' Mt', 1, 1800);
          counter('kv-2', 0, 3.45,  ' t',  2, 1800);
          counter('kv-3', 0, 312.6, ' Mt', 1, 1800);
          counter('kv-4', 0, 3760,  '',    0, 1800);
          counter('kv-5', 0, 930,   '%',   0, 1600);
        }, 950);

        /* Enter button */
        document.getElementById('c-enter-btn')
          .addEventListener('click', function() {
            var cover = document.getElementById('cover-page');
            cover.classList.add('hidden');
            setTimeout(function() { cover.style.display='none'; }, 1050);
          });
      });
    "))
  ),
  
  titlePanel("Vietnam Climate Responsibility Dashboard"),
  
  # ── COVER PAGE — PASTE LOCATION 3 ─────────────────────────────────────────
  tags$div(id="cover-page",
           
           tags$div(id="cover-bg-grad"),
           tags$div(id="cover-grid"),
           tags$canvas(id="cover-canvas"),
           tags$div(class="c-orb c-orb-1"),
           tags$div(class="c-orb c-orb-2"),
           tags$div(class="c-orb c-orb-3"),
           
           tags$div(class="c-wave-wrap",
                    tags$div(class="c-wave c-wave-a", HTML('
        <svg viewBox="0 0 1440 130" preserveAspectRatio="none"
             xmlns="http://www.w3.org/2000/svg">
          <path d="M0,65 C240,105 480,25 720,65 C960,105 1200,25 1440,65
                   L1440,130 L0,130 Z" fill="rgba(0,200,122,0.13)"/>
          <path d="M0,85 C360,45 720,105 1080,65 C1260,45 1380,85 1440,75
                   L1440,130 L0,130 Z" fill="rgba(0,170,255,0.07)"/>
        </svg>')),
                    tags$div(class="c-wave c-wave-b", HTML('
        <svg viewBox="0 0 1440 130" preserveAspectRatio="none"
             xmlns="http://www.w3.org/2000/svg">
          <path d="M0,45 C180,85 360,15 540,55 C720,95 900,15 1080,50
                   C1260,85 1380,25 1440,45 L1440,130 L0,130 Z"
                fill="rgba(0,200,122,0.07)"/>
        </svg>'))
           ),
           
           tags$div(class="c-content",
                    
                    tags$div(class="c-eyebrow",
                             "Vietnam \u00b7 Climate Responsibility \u00b7 1990\u20132024"),
                    
                    tags$h1(class="c-title",
                            "Vietnam Climate", tags$br(),
                            tags$span(class="c-title-accent", "Responsibility Dashboard")),
                    
                    tags$p(class="c-sub",
                           "GHG Emissions \u00b7 200+ Countries \u00b7 10 Sectors \u00b7 7 Periods"),
                    
                    tags$p(class="c-glance-label",
                           "\u2500\u2500  Dashboard at a Glance  \u2500\u2500"),
                    
                    tags$div(class="c-kpi-grid",
                             
                             tags$div(class="c-kpi",
                                      tags$span(class="c-kpi-icon", "\U0001F1FB\U0001F1F3"),
                                      tags$div(class="c-kpi-val", tags$span(id="kv-1", "0 Mt")),
                                      tags$div(class="c-kpi-delta delta-bad", "\u2191 930% since 1990"),
                                      tags$div(class="c-kpi-label",
                                               "Vietnam Total CO\u2082", tags$br(), "2020\u20132024"),
                                      tags$span(class="c-kpi-tab", "Emissions Share tab")),
                             
                             tags$div(class="c-kpi",
                                      tags$span(class="c-kpi-icon", "\U0001F4A8"),
                                      tags$div(class="c-kpi-val", tags$span(id="kv-2", "0.00 t")),
                                      tags$div(class="c-kpi-delta delta-warn", "#28 in Asia"),
                                      tags$div(class="c-kpi-label",
                                               "CO\u2082 per Capita", tags$br(), "tonnes / person"),
                                      tags$span(class="c-kpi-tab", "Per Capita tab")),
                             
                             tags$div(class="c-kpi",
                                      tags$span(class="c-kpi-icon", "\U0001F4E4"),
                                      tags$div(class="c-kpi-val", tags$span(id="kv-3", "0 Mt")),
                                      tags$div(class="c-kpi-delta delta-good", "Net Exporter"),
                                      tags$div(class="c-kpi-label",
                                               "Responsibility Gap", tags$br(), "Prod \u2212 Cons GHG"),
                                      tags$span(class="c-kpi-tab", "Time Series tab")),
                             
                             tags$div(class="c-kpi",
                                      tags$span(class="c-kpi-icon", "\U0001F4C9"),
                                      tags$div(class="c-kpi-val", tags$span(id="kv-4", "0")),
                                      tags$div(class="c-kpi-delta delta-bad", "\u2193 54% since 1990"),
                                      tags$div(class="c-kpi-label",
                                               "GDP earned per tonne", tags$br(),
                                               "of CO\u2082 emitted (USD)"),
                                      # Progress bar showing Vietnam vs global average
                                      HTML('
            <div style="margin-top:8px;">
              <div style="display:flex; justify-content:space-between;
                          font-family:Exo 2,sans-serif; font-size:8px;
                          color:rgba(255,255,255,0.3); margin-bottom:3px;">
                <span>VNM</span><span>World avg ~$16k</span>
              </div>
              <div style="background:rgba(255,255,255,0.07);
                          border-radius:10px; height:5px; overflow:hidden;">
                <div style="width:23%; height:100%; border-radius:10px;
                            background:linear-gradient(90deg,#9b59b6,#e74c3c);">
                </div>
              </div>
            </div>
          '),
                                      tags$span(class="c-kpi-tab", "Efficiency Analysis tab")),
                             
                             tags$div(class="c-kpi",
                                      tags$span(class="c-kpi-icon", "\U0001F50D"),
                                      tags$div(class="c-kpi-val", tags$span(id="kv-5", "0%")),
                                      tags$div(class="c-kpi-delta delta-warn", "Above trend"),
                                      tags$div(class="c-kpi-label",
                                               "CO\u2082 per Capita Growth", tags$br(), "since 1990"),
                                      tags$span(class="c-kpi-tab", "Outlier Detection tab"))
                    ),
                    
                    tags$div(class="c-btn-wrap",
                             tags$button(id="c-enter-btn",
                                         "Enter Dashboard",
                                         tags$span(class="c-arrow", "\u2192")))
           ),
           
           tags$div(class="c-tags",
                    tags$span(class="c-tag", "Emissions Share"),
                    tags$span(class="c-tag", "Per Capita"),
                    tags$span(class="c-tag", "Responsibility Gap"),
                    tags$span(class="c-tag", "Carbon Efficiency"),
                    tags$span(class="c-tag", "Outlier Detection"),
                    tags$span(class="c-tag", "Sectoral Trends"),
                    tags$span(class="c-tag", "Global Map"))
  ),
  # ── END COVER PAGE ──────────────────────────────────────────────────────────
  
  sidebarLayout(
    
    sidebarPanel(
      class = "sidebar",
      
      selectizeInput("main_countries",
                     "Select Countries (Max 5) — for Time Series, Per Capita & Sectoral:",
                     choices  = sort(unique(ghg_data$Entity)),
                     selected = "Vietnam",
                     multiple = TRUE,
                     options  = list(maxItems = 5)),
      
      selectizeInput("share_countries",
                     "Add Countries to Emissions Donut (Max 5):",
                     choices  = sort(setdiff(
                       unique(carbon_data$Entity),
                       c(CONTINENT_ENTITIES, "World", "Vietnam",
                         grep("GCP|WB|excl|income|OECD|Antarctica|International",
                              unique(carbon_data$Entity), value = TRUE))
                     )),
                     multiple = TRUE,
                     options  = list(maxItems = 5)),
      
      selectInput("sector", "Select GHG Emission Sector:",
                  choices = unique(ghg_sector_long$Sector)),
      
      radioButtons("metric", "Emission Accounting Type:",
                   choices  = c("Production vs Consumption" = "both"),
                   selected = "both"),
      
      selectInput("rank_type", "Country Ranking:",
                  choices  = c("Top 10 Countries"        = "top10",
                               "Bottom 10 Countries"     = "bottom10",
                               "Custom (Top / Bottom N)" = "custom"),
                  selected = "top10"),
      
      conditionalPanel(
        condition = "input.rank_type == 'custom'",
        radioButtons("custom_direction", "Custom Ranking Direction:",
                     choices  = c("Top Countries"    = "top",
                                  "Bottom Countries" = "bottom"),
                     selected = "top"),
        numericInput("custom_n", "Number of Countries (N):",
                     value = 5, min = 1, max = 50, step = 1)),
      
      radioButtons("value_format", "Display Values As:",
                   choices  = c("Absolute Values"  = "absolute",
                                "Percentage Share" = "percent"),
                   selected = "absolute"),
      
      sliderInput("period", "Select Period:",
                  min     = 1,
                  max     = length(levels(ghg_data$Period)),
                  value   = length(levels(ghg_data$Period)),
                  step    = 1,
                  animate = TRUE)
    ),
    
    mainPanel(
      tabsetPanel(
        
        # ── Tab 1 ──────────────────────────────────────────────────────────
        tabPanel("Per Capita Comparison",
                 div(class="panel-title blue", "Per Capita Comparison"),
                 div(class="panel-box", plotlyOutput("pc_plot", height="600px"))),
        
        # ── Tab 2 ──────────────────────────────────────────────────────────
        tabPanel("GDP vs Emissions",
                 div(class="panel-title red", "GDP vs Emissions"),
                 div(class="panel-box", plotlyOutput("scatter_plot", height="600px"))),
        
        # ── Tab 3 ──────────────────────────────────────────────────────────
        tabPanel("Emissions Share",
                 div(class="panel-title green", "Emissions Share"),
                 div(class="panel-box",
                     plotlyOutput("share_plot", height="600px"))),
        
        # == Tab 4 =======================================================================
        tabPanel("Time Series",
                 div(class="panel-title blue",
                     "Vietnam CO\u2082 Emissions Over Time"),
                 div(class="panel-box",
                     radioButtons(
                       "ts_view",
                       label    = NULL,
                       choices  = c("Total CO\u2082 Emissions" = "total",
                                    "CO\u2082 per Capita"      = "percapita"),
                       selected = "total",
                       inline   = TRUE
                     ),
                     hr(style = "margin:8px 0;"),
                     plotlyOutput("ts_plot_main", height="500px"))),
        
        # ── Tab 5 ──────────────────────────────────────────────────────────
        tabPanel("Cross-Country Comparison",
                 div(class="panel-title red", "Cross-Country Climate Responsibility"),
                 div(class="panel-box", plotlyOutput("cc_plot", height="600px"))),
        
        # ── Tab 6 ──────────────────────────────────────────────────────────
        tabPanel("Sectoral Composition",
                 div(class="panel-title green", "Sector-wise GHG Emissions"),
                 div(class="panel-box", plotlyOutput("sector_plot", height="600px"))),
        
        # ── Tab 7 ──────────────────────────────────────────────────────────
        tabPanel("Global Map",
                 div(class="panel-title purple", "Global Map"),
                 div(class="panel-box", plotlyOutput("map_plot", height="600px"))),
        
        
        # ── Tab 9 ──────────────────────────────────────────────────────────
        tabPanel("Efficiency Analysis",
                 div(class="panel-title blue",
                     "Efficiency Analysis: GDP per Unit of Carbon"),
                 div(class="panel-box",
                     fluidRow(
                       column(4, radioButtons("eff_view", "Select View:",
                                              choices  = c("Efficiency Ranking"   = "ranking",
                                                           "Efficiency Trend"     = "trend",
                                                           "Development Quadrant" = "quadrant"),
                                              selected = "ranking")),
                       column(4, radioButtons("eff_basis", "Emission Basis:",
                                              choices  = c("Production-based"  = "production",
                                                           "Consumption-based" = "consumption"),
                                              selected = "production")),
                       column(4,
                              conditionalPanel(
                                condition = "input.eff_view == 'ranking'",
                                sliderInput("eff_top_n",
                                            "Show Top/Bottom N countries:",
                                            min=5, max=30, value=15, step=5)),
                              conditionalPanel(
                                condition = "input.eff_view == 'trend'",
                                selectizeInput("eff_peer_countries",
                                               "Compare Vietnam with (Max 6):",
                                               choices  = NULL,
                                               multiple = TRUE,
                                               options  = list(maxItems = 6))))),
                     hr(),
                     plotlyOutput("eff_main_plot", height="520px"),
                     hr(),
                     fluidRow(
                       column(3, div(style="background:#e3f2fd;
                     border-left:5px solid #1f77b4;
                     padding:12px; border-radius:8px; min-height:90px;",
                                     tags$b("\U0001F30D Vietnam's Efficiency Rank"),
                                     uiOutput("eff_vn_rank"))),
                       column(3, div(style="background:#e8f5e9;
                     border-left:5px solid #2ca02c;
                     padding:12px; border-radius:8px; min-height:90px;",
                                     tags$b("\U0001F4C8 Most Improved Since 1990"),
                                     uiOutput("eff_most_improved"))),
                       column(3, div(style="background:#ffebee;
                     border-left:5px solid #d62728;
                     padding:12px; border-radius:8px; min-height:90px;",
                                     tags$b("\U0001F4C9 Most Deteriorated Since 1990"),
                                     uiOutput("eff_most_deteriorated"))),
                       column(3, div(style="background:#fff3e0;
                     border-left:5px solid #ff7f0e;
                     padding:12px; border-radius:8px; min-height:90px;",
                                     tags$b("\U0001F1FB\U0001F1F3 Vietnam Trend"),
                                     uiOutput("eff_vn_trend"))))))
        
      ) # closes tabsetPanel
    )   # closes mainPanel
  )     # closes sidebarLayout
)       # closes fluidPage

# ── Server ─────────────────────────────────────────────────────────────────────
server <- function(input, output, session) {
  
  # == Dark theme for all ggplots ================================================
  dark_theme <- function(base_size = 13) {
    theme_minimal(base_size = base_size) %+replace%
      theme(
        panel.background      = element_rect(fill = "transparent", colour = NA),
        plot.background       = element_rect(fill = "transparent", colour = NA),
        legend.background     = element_rect(fill = "transparent", colour = NA),
        legend.box.background = element_rect(fill = "transparent", colour = NA),
        legend.key            = element_rect(fill = "transparent", colour = NA),
        
        panel.grid.major  = element_line(colour = "#1a3a2a", linewidth = 0.4),
        panel.grid.minor  = element_blank(),
        
        # ALL axis text forced to light color
        axis.text         = element_text(colour = "#a8c5b5",
                                         family = "Exo 2", size = 10),
        axis.text.x       = element_text(colour = "#a8c5b5",
                                         family = "Exo 2", size = 10,
                                         angle = 0),
        axis.text.y       = element_text(colour = "#a8c5b5",
                                         family = "Exo 2", size = 10),
        axis.title        = element_text(colour = "#00c87a",
                                         family = "Exo 2", size = 11,
                                         face = "bold"),
        axis.title.x      = element_text(colour = "#00c87a",
                                         family = "Exo 2", size = 11,
                                         face = "bold", margin = margin(t=8)),
        axis.title.y      = element_text(colour = "#00c87a",
                                         family = "Exo 2", size = 11,
                                         face = "bold", margin = margin(r=8)),
        axis.ticks        = element_line(colour = "#1a3a2a"),
        axis.line         = element_blank(),
        
        plot.title        = element_text(colour = "#ffffff",
                                         family = "Orbitron", size = 13,
                                         face = "bold", margin = margin(b=6)),
        plot.subtitle     = element_text(colour = "#7ecfb0",
                                         family = "Exo 2", size = 10,
                                         margin = margin(b=10)),
        plot.caption      = element_text(colour = "#4a7a60",
                                         family = "Exo 2", size = 8),
        plot.margin       = margin(10, 10, 10, 10),
        
        legend.text       = element_text(colour = "#a8c5b5",
                                         family = "Exo 2", size = 10),
        legend.title      = element_text(colour = "#00c87a",
                                         family = "Exo 2", size = 10,
                                         face = "bold"),
        
        strip.text        = element_text(colour = "#ffffff",
                                         family = "Exo 2", face = "bold"),
        strip.background  = element_rect(fill = "rgba(0,200,122,0.1)",
                                         colour = NA)
      )
  }
  
  # == Dark plotly layout wrapper ================================================
  dark_plotly <- function(p, height = 600) {
    p %>%
      layout(
        height        = height,
        paper_bgcolor = "rgba(0,0,0,0)",
        plot_bgcolor  = "rgba(0,0,0,0)",
        font = list(family = "Exo 2, sans-serif",
                    color  = "#a8c5b5"),
        xaxis = list(
          gridcolor     = "#1a3a2a",
          zerolinecolor = "#00c87a",
          zerolinewidth = 1,
          color         = "#a8c5b5",
          tickcolor     = "#a8c5b5",
          tickfont      = list(color  = "#a8c5b5",
                               family = "Exo 2",
                               size   = 11),
          titlefont     = list(color  = "#00c87a",
                               family = "Exo 2",
                               size   = 12)),
        yaxis = list(
          gridcolor     = "#1a3a2a",
          zerolinecolor = "#00c87a",
          zerolinewidth = 1,
          color         = "#a8c5b5",
          tickcolor     = "#a8c5b5",
          tickfont      = list(color  = "#a8c5b5",
                               family = "Exo 2",
                               size   = 11),
          titlefont     = list(color  = "#00c87a",
                               family = "Exo 2",
                               size   = 12)),
        legend = list(
          bgcolor     = "rgba(3,13,26,0.7)",
          bordercolor = "rgba(0,200,122,0.3)",
          borderwidth = 1,
          font        = list(color  = "#a8c5b5",
                             family = "Exo 2",
                             size   = 11)),
        title = list(
          font = list(color  = "#ffffff",
                      family = "Orbitron",
                      size   = 14))
      ) %>%
      config(displaylogo = FALSE)
  }
  
  # Tracks which continent the user has clicked in the donut
  selected_continent <- reactiveVal(NULL)
  
  # Populate peer country dropdown for efficiency trend view
  observe({
    req(nrow(carbon_data) > 0)
    peers_available <- sort(setdiff(
      unique(carbon_data$Entity),
      c(CONTINENT_ENTITIES, "World", "Vietnam",
        grep("GCP|WB|excl|income|OECD|Antarctica|International",
             unique(carbon_data$Entity), value = TRUE))
    ))
    updateSelectizeInput(session, "eff_peer_countries",
                         choices  = peers_available,
                         selected = c("China", "India", "Thailand", "Indonesia", "Malaysia"),
                         server   = TRUE)
  })
  
  # Helper: resolve the current period label
  selected_period <- reactive({
    levels(ghg_data$Period)[input$period]
  })
  
  # ── Per Capita ──────────────────────────────────────────────────────────────
  output$pc_plot <- renderPlotly({
    
    # Uses the same country selection as Sector Comparison
    countries_to_show <- unique(c("Vietnam", input$main_countries))
    
    df <- carbon_data %>%
      filter(
        Period == selected_period(),
        Entity %in% countries_to_show
      ) %>%
      mutate(highlight = ifelse(Entity == "Vietnam", "Vietnam", "Others"))
    
    # Fallback: if no countries selected yet, show top 8
    if (length(input$main_countries) == 0) {
      df <- carbon_data %>%
        filter(Period == selected_period()) %>%
        arrange(desc(co2_pc)) %>%
        slice_head(n = 8) %>%
        bind_rows(
          carbon_data %>%
            filter(Period == selected_period(), Entity == "Vietnam")
        ) %>%
        distinct(Entity, .keep_all = TRUE) %>%
        mutate(highlight = ifelse(Entity == "Vietnam", "Vietnam", "Others"))
    }
    
    p <- ggplot(df, aes(
      x    = reorder(Entity, co2_pc),
      y    = co2_pc,
      fill = highlight,
      text = paste0("Country: ", Entity,
                    "<br>Per Capita CO2: ", round(co2_pc, 2))
    )) +
      geom_col() +
      coord_flip() +
      scale_fill_manual(values = c("Vietnam" = "red", "Others" = "steelblue")) +
      labs(x = "", y = "CO2 per capita", fill = "") +
      dark_theme(base_size = 14)
    
    ggplotly(p, tooltip = "text") %>% dark_plotly(height = 600)
  })
  
  # ── GDP vs Emissions ────────────────────────────────────────────────────────
  output$scatter_plot <- renderPlotly({
    
    df <- carbon_data %>%
      filter(Period == selected_period()) %>%
      mutate(highlight = ifelse(Entity == "Vietnam", "Vietnam", "Others"))
    
    p <- ggplot(df, aes(
      x     = gdp_pc,
      y     = co2_pc,
      color = highlight,
      text  = paste0("Country: ", Entity,
                     "<br>GDP per capita: ", round(gdp_pc, 2),
                     "<br>CO2 per capita: ", round(co2_pc, 2))
    )) +
      geom_point(data = filter(df, highlight == "Others"),
                 size = 3, alpha = 0.6) +
      # Vietnam plotted on top so it is never hidden
      geom_point(data = filter(df, highlight == "Vietnam"),
                 size = 5, shape = 18) +
      scale_color_manual(values = c("Vietnam" = "red", "Others" = "steelblue")) +
      labs(x = "GDP per capita", y = "CO2 per capita", color = "") +
      dark_theme(base_size = 14)
    
    ggplotly(p, tooltip = "text") %>% dark_plotly(height = 600)
  })
  
  # ── Emissions Share (pie / donut) ───────────────────────────────────────────
  output$share_plot <- renderPlotly({
    
    period_now <- selected_period()
    
    # ── CONTINENT VIEW (default) ─────────────────────────────────────────────
    if (is.null(selected_continent())) {
      
      # Countries always shown individually (Vietnam + user selection)
      pinned_countries <- unique(c("Vietnam", input$share_countries))
      
      # Get continent totals
      df_cont <- carbon_data %>%
        filter(Period == period_now, Entity %in% CONTINENT_ENTITIES)
      
      # Get pinned country rows
      df_pinned <- carbon_data %>%
        filter(Period == period_now, Entity %in% pinned_countries)
      
      # Subtract each pinned country from its continent
      for (ctry in pinned_countries) {
        belongs_to <- names(Filter(function(x) ctry %in% x,
                                   country_continent_map))
        if (length(belongs_to) == 0) next
        cont_name <- belongs_to[1]
        ctry_row <- df_pinned %>% filter(Entity == ctry)
        if (nrow(ctry_row) == 0) next
        df_cont <- df_cont %>%
          mutate(
            co2_total    = ifelse(Entity == cont_name,
                                  co2_total - ctry_row$co2_total[1],
                                  co2_total),
            share_global = ifelse(Entity == cont_name,
                                  share_global - ctry_row$share_global[1],
                                  share_global)
          )
      }
      
      # Rename continents that had countries carved out
      pinned_conts <- names(Filter(function(x)
        any(pinned_countries %in% x), country_continent_map))
      df_cont <- df_cont %>%
        mutate(Entity = ifelse(
          Entity %in% pinned_conts,
          paste0(Entity, " (rest)"),
          Entity
        ))
      
      # ── ORDER FIX: each country sits next to its continent ──────────────────
      continent_order <- c(
        "Asia", "Asia (rest)",
        "North America", "North America (rest)",
        "Europe", "Europe (rest)",
        "Africa", "Africa (rest)",
        "South America", "South America (rest)",
        "Oceania", "Oceania (rest)",
        "International shipping",
        "International aviation"
      )
      
      df_combined <- bind_rows(df_cont, df_pinned) %>%
        filter(co2_total > 0 | Entity %in% pinned_countries)
      
      final_order <- c()
      for (slot in continent_order) {
        if (slot %in% df_combined$Entity) {
          final_order <- c(final_order, slot)
        }
        base_cont <- gsub(" \\(rest\\)", "", slot)
        if (grepl("rest", slot) && base_cont %in% names(country_continent_map)) {
          pinned_here <- intersect(pinned_countries,
                                   country_continent_map[[base_cont]])
          final_order <- c(final_order,
                           pinned_here[pinned_here %in% df_combined$Entity])
        }
      }
      remaining <- setdiff(df_combined$Entity, final_order)
      final_order <- c(final_order, remaining)
      
      df <- df_combined %>%
        mutate(Entity = factor(Entity, levels = final_order)) %>%
        arrange(Entity) %>%
        mutate(Entity = as.character(Entity))
      # ── END ORDER FIX ────────────────────────────────────────────────────────
      
      # Value format
      if (input$value_format == "absolute") {
        df$plot_value <- df$co2_total
        df$label_text <- paste0(scales::comma(round(df$co2_total / 1e6, 1)), " Mt")
      } else {
        df$plot_value <- df$share_global
        df$label_text <- paste0(round(df$share_global, 2), "%")
      }
      
      # Colors
      base_colors <- c(
        "Africa"                 = "#2ca02c",
        "Africa (rest)"          = "#2ca02c",
        "Asia"                   = "#d62728",
        "Asia (rest)"            = "#d62728",
        "Europe"                 = "#1f77b4",
        "Europe (rest)"          = "#1f77b4",
        "North America"          = "#ff7f0e",
        "North America (rest)"   = "#ff7f0e",
        "South America"          = "#9467bd",
        "South America (rest)"   = "#9467bd",
        "Oceania"                = "#8c564b",
        "Oceania (rest)"         = "#8c564b",
        "International aviation" = "#7f7f7f",
        "International shipping" = "#bcbd22",
        "Vietnam"                = "#e74c3c"
      )
      extra_pinned   <- setdiff(pinned_countries, "Vietnam")
      extra_palette  <- c("#f39c12","#1abc9c","#8e44ad","#2980b9","#27ae60")
      for (i in seq_along(extra_pinned)) {
        base_colors[extra_pinned[i]] <- extra_palette[i]
      }
      slice_colors <- base_colors[df$Entity]
      slice_colors[is.na(slice_colors)] <- "#cccccc"
      
      plot_ly(
        df,
        labels        = ~Entity,
        values        = ~plot_value,
        type          = "pie",
        hole          = 0.5,
        textinfo      = "label+text",
        text          = ~label_text,
        marker        = list(colors = unname(slice_colors)),
        hovertemplate = paste0(
          "<b>%{label}</b><br>",
          ifelse(input$value_format == "absolute",
                 "CO2: %{text}", "Share: %{text}"),
          "<extra></extra>"
        ),
        source = "share_donut"
      ) %>%
        layout(
          height        = 600,
          paper_bgcolor = "rgba(0,0,0,0)",
          plot_bgcolor  = "rgba(0,0,0,0)",
          font          = list(family = "Exo 2", color = "rgba(255,255,255,0.75)"),
          title         = list(
            text = paste0("Global Emissions by Continent — ", period_now),
            font = list(color = "#ffffff", family = "Orbitron", size = 13)),
          showlegend  = TRUE,
          legend      = list(
            bgcolor     = "rgba(3,13,26,0.6)",
            bordercolor = "rgba(0,200,122,0.2)",
            borderwidth = 1,
            font        = list(color = "rgba(255,255,255,0.75)")),
          annotations = list(list(
            text      = "Vietnam<br>always shown",
            x = 0.5, y = 0.5,
            font      = list(size = 12, color = "#e74c3c"),
            showarrow = FALSE))
        ) %>%
        config(displaylogo = FALSE)
      
      # ── COUNTRY VIEW (after clicking a continent) ────────────────────────────
    } else {
      
      cont <- selected_continent()
      
      # Countries in this continent from our map
      cont_countries <- country_continent_map[[cont]]
      
      if (is.null(cont_countries)) {
        # For International aviation/shipping — no drill-down
        selected_continent(NULL)
        return(NULL)
      }
      
      # Always include Vietnam + sidebar selection within this continent
      sidebar_sel <- input$share_countries
      extra <- intersect(sidebar_sel, cont_countries)
      focus  <- unique(c("Vietnam", extra))
      
      df_countries <- carbon_data %>%
        filter(Period == period_now, Entity %in% cont_countries)
      
      # Named countries to show individually
      df_named <- df_countries %>% filter(Entity %in% focus)
      
      # Rest lumped as "Rest of [Continent]"
      df_rest <- df_countries %>%
        filter(!Entity %in% focus) %>%
        summarise(
          co2_total    = sum(co2_total,    na.rm = TRUE),
          share_global = sum(share_global, na.rm = TRUE)
        ) %>%
        mutate(Entity = paste0("Rest of ", cont))
      
      df <- bind_rows(df_named, df_rest)
      
      if (input$value_format == "absolute") {
        df$plot_value <- df$co2_total
        df$label_text <- paste0(scales::comma(round(df$co2_total / 1e6, 1)), " Mt")
      } else {
        df$plot_value <- df$share_global
        df$label_text <- paste0(round(df$share_global, 2), "%")
      }
      
      # Vietnam always red
      n_slices   <- nrow(df)
      base_cols  <- RColorBrewer::brewer.pal(max(3, n_slices), "Set2")
      slice_cols <- base_cols[seq_len(n_slices)]
      vn_idx     <- which(df$Entity == "Vietnam")
      if (length(vn_idx) > 0) slice_cols[vn_idx] <- "red"
      
      plot_ly(
        df,
        labels        = ~Entity,
        values        = ~plot_value,
        type          = "pie",
        hole          = 0.5,
        textinfo      = "label+text",
        text          = ~label_text,
        marker        = list(colors = slice_cols),
        hovertemplate = paste0(
          "<b>%{label}</b><br>",
          ifelse(input$value_format == "absolute",
                 "CO2: %{text}", "Share: %{text}"),
          "<extra></extra>"
        )
      ) %>%
        layout(
          height        = 600,
          paper_bgcolor = "rgba(0,0,0,0)",
          plot_bgcolor  = "rgba(0,0,0,0)",
          font          = list(family = "Exo 2",
                               color = "rgba(255,255,255,0.75)"),
          title         = list(
            text = paste0(cont, " — Country Breakdown — ", period_now),
            font = list(color = "#ffffff", family = "Orbitron", size = 13)),
          showlegend    = TRUE,
          legend        = list(
            bgcolor     = "rgba(3,13,26,0.6)",
            bordercolor = "rgba(0,200,122,0.2)",
            borderwidth = 1,
            font        = list(color = "rgba(255,255,255,0.75)")),
          annotations   = list(list(
            text      = paste0("<b>", cont, "</b>"),
            x = 0.5, y = 0.5,
            font      = list(size = 12, color = "rgba(255,255,255,0.5)"),
            showarrow = FALSE))
        ) %>%
        config(displaylogo = FALSE)
    }
  })
  
  # ── Handle continent click to drill down ─────────────────────────────────────
  observeEvent(event_data("plotly_click", source = "share_donut"), {
    click <- event_data("plotly_click", source = "share_donut")
    if (!is.null(click)) {
      label <- click$customdata
      if (is.null(label)) {
        # fallback: use pointNumber to get entity name
        period_now    <- selected_period()
        df_check <- carbon_data %>%
          filter(Period == period_now, Entity %in% CONTINENT_ENTITIES)
        idx <- (click$pointNumber + 1)
        if (idx <= nrow(df_check)) {
          chosen <- df_check$Entity[idx]
          if (chosen %in% names(country_continent_map)) {
            selected_continent(chosen)
          }
        }
      } else if (label %in% names(country_continent_map)) {
        selected_continent(label)
      }
    }
  })
  
  
  # == Time Series ================================================================
  output$ts_plot_main <- renderPlotly({
    
    countries_ts <- unique(c("Vietnam", input$main_countries))
    
    df <- carbon_data %>%
      filter(Entity %in% countries_ts) %>%
      droplevels() %>%
      mutate(Period_label = as.character(Period)) %>%
      arrange(Period_label)
    
    req(nrow(df) > 0)
    
    period_levels <- sort(unique(df$Period_label))
    df <- df %>%
      mutate(Period_label = factor(Period_label, levels = period_levels))
    
    other_ts <- setdiff(countries_ts, "Vietnam")
    ts_palette <- c("#1f77b4","#2ca02c","#ff7f0e","#9467bd","#8c564b")
    ts_color_map <- if (length(other_ts) == 0) {
      c("Vietnam" = "#e74c3c")
    } else {
      c("Vietnam" = "#e74c3c",
        setNames(ts_palette[seq_along(other_ts)], other_ts))
    }
    
    df_vietnam <- filter(df, Entity == "Vietnam")
    df_others  <- filter(df, Entity != "Vietnam")
    
    if (input$ts_view == "total") {
      
      df_vietnam <- df_vietnam %>% mutate(co2_mt = co2_total / 1e6)
      df_others  <- df_others  %>% mutate(co2_mt = co2_total / 1e6)
      
      p <- ggplot() +
        # Other countries layer — only added if non-empty
        { if (nrow(df_others) > 0)
          list(
            geom_line(data  = df_others,
                      aes(x=Period_label, y=co2_mt,
                          color=Entity, group=Entity,
                          text=paste0("<b>",Entity,"</b><br>",
                                      "Period: ",as.character(Period_label),"<br>",
                                      "Total CO\u2082: ",round(co2_mt,1)," Mt")),
                      linewidth=1.4, alpha=0.8),
            geom_point(data = df_others,
                       aes(x=Period_label, y=co2_mt,
                           color=Entity, group=Entity,
                           text=paste0("<b>",Entity,"</b><br>",
                                       "Period: ",as.character(Period_label),"<br>",
                                       "Total CO\u2082: ",round(co2_mt,1)," Mt")),
                       size=3, alpha=0.8)
          )
        } +
        # Vietnam layer — always present
        geom_line(data  = df_vietnam,
                  aes(x=Period_label, y=co2_mt, group=Entity,
                      text=paste0("<b>Vietnam</b><br>",
                                  "Period: ",as.character(Period_label),"<br>",
                                  "Total CO\u2082: ",round(co2_mt,1)," Mt")),
                  linewidth=2.5, color="#e74c3c") +
        geom_point(data = df_vietnam,
                   aes(x=Period_label, y=co2_mt, group=Entity,
                       text=paste0("<b>Vietnam</b><br>",
                                   "Period: ",as.character(Period_label),"<br>",
                                   "Total CO\u2082: ",round(co2_mt,1)," Mt")),
                   size=5, color="#e74c3c", shape=18) +
        { if (length(other_ts) > 0)
          scale_color_manual(values=ts_color_map)
        } +
        scale_y_continuous(labels=scales::comma) +
        labs(title    = "Total CO\u2082 Emissions",
             subtitle = "Million tonnes per year",
             x="Period", y="CO\u2082 (Mt)", color="Country") +
        dark_theme(base_size=13) +
        theme(axis.text.x=element_text(angle=45, hjust=1, colour="#a8c5b5"))
      
    } else {
      
      p <- ggplot() +
        { if (nrow(df_others) > 0)
          list(
            geom_line(data  = df_others,
                      aes(x=Period_label, y=co2_pc,
                          color=Entity, group=Entity,
                          text=paste0("<b>",Entity,"</b><br>",
                                      "Period: ",as.character(Period_label),"<br>",
                                      "CO\u2082 per capita: ",round(co2_pc,2)," tonnes/person")),
                      linewidth=1.4, alpha=0.8),
            geom_point(data = df_others,
                       aes(x=Period_label, y=co2_pc,
                           color=Entity, group=Entity,
                           text=paste0("<b>",Entity,"</b><br>",
                                       "Period: ",as.character(Period_label),"<br>",
                                       "CO\u2082 per capita: ",round(co2_pc,2)," tonnes/person")),
                       size=3, alpha=0.8)
          )
        } +
        geom_line(data  = df_vietnam,
                  aes(x=Period_label, y=co2_pc, group=Entity,
                      text=paste0("<b>Vietnam</b><br>",
                                  "Period: ",as.character(Period_label),"<br>",
                                  "CO\u2082 per capita: ",round(co2_pc,2)," tonnes/person")),
                  linewidth=2.5, color="#e74c3c") +
        geom_point(data = df_vietnam,
                   aes(x=Period_label, y=co2_pc, group=Entity,
                       text=paste0("<b>Vietnam</b><br>",
                                   "Period: ",as.character(Period_label),"<br>",
                                   "CO\u2082 per capita: ",round(co2_pc,2)," tonnes/person")),
                   size=5, color="#e74c3c", shape=18) +
        { if (length(other_ts) > 0)
          scale_color_manual(values=ts_color_map)
        } +
        scale_y_continuous(labels=scales::comma) +
        labs(title    = "CO\u2082 per Capita",
             subtitle = "Tonnes of CO\u2082 per person per year",
             x="Period", y="CO\u2082 per capita (t)", color="Country") +
        dark_theme(base_size=13) +
        theme(axis.text.x=element_text(angle=45, hjust=1, colour="#a8c5b5"))
    }
    
    ggplotly(p, tooltip="text") %>% dark_plotly(height=500)
  })
  
  # ── Cross-Country ────────────────────────────────────────────────────────────
  output$cc_plot <- renderPlotly({
    
    df <- ghg_data %>%
      filter(Period == selected_period()) %>%
      mutate(
        Value   = Responsibility_Gap,
        Percent = (abs(Value) / sum(abs(Value), na.rm = TRUE)) * 100
      )
    
    n <- if (input$rank_type == "top10") 10
    else if (input$rank_type == "bottom10") 10
    else input$custom_n
    
    go_top <- (input$rank_type == "top10") ||
      (input$rank_type == "custom" && input$custom_direction == "top")
    
    df_ranked <- if (go_top) {
      df %>% arrange(desc(Value)) %>% slice_head(n = n)
    } else {
      df %>% arrange(Value) %>% slice_head(n = n)
    }
    
    # Always include Vietnam
    df_vietnam <- df %>% filter(Entity == "Vietnam")
    df_final   <- bind_rows(df_ranked, df_vietnam) %>%
      distinct(Entity, .keep_all = TRUE)
    
    plot_value <- if (input$value_format == "percent") df_final$Percent else df_final$Value
    
    p <- ggplot(df_final, aes(
      x    = reorder(Entity, plot_value),
      y    = plot_value,
      fill = ifelse(Entity == "Vietnam", "Vietnam", "Others"),
      text = paste0(Entity,
                    "<br>Responsibility Gap: ", scales::comma(Value),
                    "<br>Share: ", round(Percent, 2), "%")
    )) +
      geom_col() +
      coord_flip() +
      scale_fill_manual(values = c("Vietnam" = "red", "Others" = "steelblue")) +
      labs(
        y    = ifelse(input$value_format == "percent",
                      "Percentage Share (%)", "GHG Responsibility (CO\u2082 eq)"),
        x    = "",
        fill = ""
      ) +
      dark_theme(base_size = 14)
    
    ggplotly(p, tooltip = "text") %>% dark_plotly(height = 600)
  })
  
  # ── Sectoral Composition ────────────────────────────────────────────────────
  output$sector_plot <- renderPlotly({
    
    req(input$main_countries)
    
    countries_to_show <- unique(c("Vietnam", input$main_countries))
    
    df <- ghg_sector_long %>%
      filter(
        Entity %in% countries_to_show,
        Sector == input$sector
      ) %>%
      mutate(
        Entity = factor(Entity, levels = countries_to_show),
        # Use Period directly as character — no numeric conversion
        Period = as.character(Period)
      ) %>%
      arrange(Period)   # ensures lines connect left to right
    
    # Build color palette
    other_countries <- setdiff(countries_to_show, "Vietnam")
    other_colors <- RColorBrewer::brewer.pal(
      max(3, length(other_countries)), "Set2"
    )[seq_along(other_countries)]
    color_map <- c("Vietnam" = "red",
                   setNames(other_colors, other_countries))
    
    p <- ggplot(df, aes(
      x     = Period,
      y     = Emissions,
      color = Entity,
      group = Entity,
      text  = paste0(
        "Country: ",   Entity,               "<br>",
        "Sector: ",    Sector,               "<br>",
        "Period: ",    Period,               "<br>",
        "Emissions: ", scales::comma(Emissions)
      )
    )) +
      geom_line(linewidth = 1.4) +
      geom_point(size = 3) +
      # Vietnam always on top, thicker
      geom_line(
        data      = filter(df, as.character(Entity) == "Vietnam"),
        linewidth = 2.5,
        color     = "red"
      ) +
      geom_point(
        data  = filter(df, as.character(Entity) == "Vietnam"),
        size  = 5,
        color = "red",
        shape = 18
      ) +
      scale_color_manual(values = color_map) +
      scale_y_continuous(labels = scales::comma) +
      labs(
        title = paste0(input$sector, ": Emissions Over Time"),
        x     = "Period",
        y     = "GHG Emissions (CO\u2082 eq)",
        color = "Country"
      ) +
      dark_theme(base_size = 14) +
      theme(axis.text.x = element_text(angle = 45, hjust = 1,
                                       colour = "#a8c5b5"))
    
    ggplotly(p, tooltip = "text") %>% dark_plotly(height = 600)
  })
  
  
  # ── Scatter plot ────────────────────────────────────────────────────────────
  output$outlier_scatter <- renderPlotly({
    
    df <- outlier_df()
    req(nrow(df) > 0)
    
    if (input$outlier_metric == "efficiency") {
      
      # Filter by scope
      df_plot <- switch(input$outlier_scope,
                        "over"  = df %>% filter(efficiency_label == "Cleaner than expected"),
                        "under" = df %>% filter(efficiency_label == "Dirtier than expected"),
                        df
      )
      
      color_map <- c(
        "Cleaner than expected" = "#2ca02c",
        "Dirtier than expected" = "#d62728",
        "Typical"               = "#aaaaaa"
      )
      
      # Trend line points
      gdp_seq    <- seq(min(df$gdp_pc), max(df$gdp_pc), length.out = 100)
      log_fit    <- lm(log(co2_pc) ~ log(gdp_pc), data = df)
      trend_co2  <- exp(predict(log_fit,
                                newdata = data.frame(gdp_pc = gdp_seq)))
      
      p <- ggplot() +
        # Trend line
        geom_line(
          data = data.frame(gdp_pc = gdp_seq, co2_pc = trend_co2),
          aes(x = gdp_pc, y = co2_pc),
          color = "#333333", linewidth = 1, linetype = "dashed"
        ) +
        # All countries
        geom_point(
          data = df_plot %>% filter(!is_vietnam),
          aes(x       = gdp_pc,
              y       = co2_pc,
              color   = efficiency_label,
              size    = co2_total,
              text    = paste0(
                "<b>", Entity, "</b><br>",
                "GDP per capita: $", scales::comma(round(gdp_pc)),  "<br>",
                "CO2 per capita: ",  round(co2_pc, 2), " t<br>",
                "Expected CO2: ",    round(predicted_co2, 2), " t<br>",
                "Deviation: ",       round(residual, 2), "<br>",
                "Status: ",          efficiency_label
              )),
          alpha = 0.75
        ) +
        # Vietnam always on top
        geom_point(
          data  = df_plot %>% filter(is_vietnam),
          aes(x = gdp_pc, y = co2_pc,
              text = paste0(
                "<b>Vietnam</b><br>",
                "GDP per capita: $", scales::comma(round(gdp_pc)),  "<br>",
                "CO2 per capita: ",  round(co2_pc, 2), " t<br>",
                "Expected CO2: ",    round(predicted_co2, 2), " t<br>",
                "Deviation: ",       round(residual, 2), "<br>",
                "Status: ",          efficiency_label
              )),
          color = "red", size = 5, shape = 18
        ) +
        scale_color_manual(values = color_map) +
        scale_size_continuous(range = c(2, 10), guide = "none") +
        scale_x_log10(labels = scales::dollar_format()) +
        scale_y_log10(labels = scales::comma) +
        labs(
          title  = "Emission Efficiency: GDP vs CO2 per Capita",
          x      = "GDP per Capita (log scale)",
          y      = "CO2 per Capita — tonnes (log scale)",
          color  = "Country Type",
          caption = "Dashed line = expected emissions given GDP. Points above = dirtier than expected."
        ) +
        dark_theme(base_size = 13) +
        theme(plot.title = element_text(face = "bold"))
      
    } else {
      
      # Responsibility gap view
      df_plot <- df %>% filter(!is.na(Responsibility_Gap))
      
      df_plot <- switch(input$outlier_scope,
                        "over"  = df_plot %>% filter(gap_label == "Hidden importer"),
                        "under" = df_plot %>% filter(gap_label == "Pollution exporter"),
                        df_plot
      )
      
      color_map2 <- c(
        "Hidden importer"   = "#1f77b4",
        "Pollution exporter"= "#ff7f0e",
        "Balanced"          = "#aaaaaa"
      )
      
      p <- ggplot(df_plot,
                  aes(x    = prod_ghg / 1e6,
                      y    = cons_ghg / 1e6,
                      color = gap_label,
                      text  = paste0(
                        "<b>", Entity, "</b><br>",
                        "Production GHG: ", round(prod_ghg/1e6, 2), " Mt<br>",
                        "Consumption GHG: ", round(cons_ghg/1e6, 2), " Mt<br>",
                        "Responsibility Gap: ",
                        scales::comma(round(Responsibility_Gap/1e6)), " Mt<br>",
                        "Type: ", gap_label
                      ))) +
        geom_abline(slope = 1, intercept = 0,
                    color = "#333333", linewidth = 1, linetype = "dashed") +
        geom_point(data = df_plot %>% filter(!is_vietnam),
                   aes(size = abs(Responsibility_Gap)), alpha = 0.75) +
        geom_point(data = df_plot %>% filter(is_vietnam),
                   color = "red", size = 5, shape = 18) +
        scale_color_manual(values = color_map2) +
        scale_size_continuous(range = c(2, 10), guide = "none") +
        scale_x_log10(labels = scales::comma) +
        scale_y_log10(labels = scales::comma) +
        labs(
          title   = "Responsibility Gap: Production vs Consumption Emissions",
          x       = "Production-based GHG (Gt, log scale)",
          y       = "Consumption-based GHG (Gt, log scale)",
          color   = "Country Type",
          caption = "Above diagonal = imports emissions (hidden importer). Below = exports emissions."
        ) +
        dark_theme(base_size = 13) +
        theme(plot.title = element_text(face = "bold"))
    }
    
    ggplotly(p, tooltip = "text") %>% dark_plotly(height = 500)
  })
  
  # ── Summary cards ───────────────────────────────────────────────────────────
  output$outlier_clean_list <- renderUI({
    top <- outlier_df() %>%
      filter(efficiency_label == "Cleaner than expected") %>%
      arrange(residual) %>%
      slice_head(n = 5)
    tags$ul(style = "padding-left:16px; margin:6px 0;",
            lapply(seq_len(nrow(top)), function(i) {
              tags$li(paste0(top$Entity[i],
                             " ($", scales::comma(round(top$gdp_pc[i])),
                             ", ", round(top$co2_pc[i], 1), "t)"))
            })
    )
  })
  
  output$outlier_dirty_list <- renderUI({
    top <- outlier_df() %>%
      filter(efficiency_label == "Dirtier than expected") %>%
      arrange(desc(residual)) %>%
      slice_head(n = 5)
    tags$ul(style = "padding-left:16px; margin:6px 0;",
            lapply(seq_len(nrow(top)), function(i) {
              tags$li(paste0(top$Entity[i],
                             " ($", scales::comma(round(top$gdp_pc[i])),
                             ", ", round(top$co2_pc[i], 1), "t)"))
            })
    )
  })
  
  output$outlier_importers_list <- renderUI({
    top <- outlier_df() %>%
      filter(!is.na(Responsibility_Gap)) %>%
      arrange(desc(Responsibility_Gap)) %>%
      slice_head(n = 5)
    tags$ul(style = "padding-left:16px; margin:6px 0;",
            lapply(seq_len(nrow(top)), function(i) {
              tags$li(paste0(top$Entity[i], " (+",
                             scales::comma(round(top$Responsibility_Gap[i]/1e6)),
                             " Mt)"))
            })
    )
  })
  
  output$outlier_exporters_list <- renderUI({
    top <- outlier_df() %>%
      filter(!is.na(Responsibility_Gap)) %>%
      arrange(Responsibility_Gap) %>%
      slice_head(n = 5)
    tags$ul(style = "padding-left:16px; margin:6px 0;",
            lapply(seq_len(nrow(top)), function(i) {
              tags$li(paste0(top$Entity[i], " (",
                             scales::comma(round(top$Responsibility_Gap[i]/1e6)),
                             " Mt)"))
            })
    )
  })
  
  # ── Vietnam context box ─────────────────────────────────────────────────────
  output$vietnam_outlier_context <- renderUI({
    vn <- outlier_df() %>% filter(Entity == "Vietnam")
    req(nrow(vn) > 0)
    
    eff_status <- vn$efficiency_label[1]
    gap_val    <- if (!is.na(vn$Responsibility_Gap[1]))
      paste0(scales::comma(round(vn$Responsibility_Gap[1]/1e6)), " Mt")
    else "N/A"
    deviation  <- round(vn$residual[1], 3)
    
    eff_color <- if (eff_status == "Cleaner than expected") "#2ca02c"
    else if (eff_status == "Dirtier than expected") "#d62728"
    else "#888888"
    
    tagList(
      tags$p(
        "Emission Efficiency: ",
        tags$b(style = paste0("color:", eff_color), eff_status),
        paste0(" (deviation from trend: ", deviation, ")")
      ),
      tags$p(
        "GDP per capita: ",
        tags$b(paste0("$", scales::comma(round(vn$gdp_pc[1])))),
        " | CO2 per capita: ",
        tags$b(paste0(round(vn$co2_pc[1], 2), " tonnes"))
      ),
      tags$p(
        "Responsibility Gap: ",
        tags$b(gap_val),
        if (!is.na(vn$Responsibility_Gap[1]) && vn$Responsibility_Gap[1] > 0)
          " → Vietnam consumes more than it produces (net importer of emissions)"
        else
          " → Vietnam produces more than it consumes (net exporter of emissions)"
      )
    )
  })
  
  # ── EFFICIENCY ANALYSIS ────────────────────────────────────────────────────
  
  eff_base_df <- reactive({
    agg_exact    <- c("World","Asia","Europe","Africa",
                      "North America","South America","Oceania",
                      "International aviation","International shipping")
    agg_patterns <- "GCP|WB|excl|income|OECD|Antarctica|International"
    
    df <- carbon_data %>%
      filter(!Entity %in% agg_exact) %>%
      filter(!grepl(agg_patterns, Entity))
    
    if (input$eff_basis == "production") {
      df %>%
        filter(!is.na(gdp_pc), !is.na(co2_pc), co2_pc > 0, gdp_pc > 0) %>%
        mutate(efficiency   = gdp_pc / co2_pc,
               emission_col = co2_pc,
               basis_label  = "Production-based CO2 per capita (tonnes)")
    } else {
      cons_col <- if ("cons_pc" %in% names(df)) "cons_pc"
      else if ("consumption-based emissions per capita" %in% names(df))
        "consumption-based emissions per capita"
      else NA
      if (is.na(cons_col)) return(data.frame())
      df %>%
        rename(cons_pc = !!sym(cons_col)) %>%
        filter(!is.na(gdp_pc), !is.na(cons_pc), cons_pc > 0, gdp_pc > 0) %>%
        mutate(efficiency   = gdp_pc / cons_pc,
               emission_col = cons_pc,
               basis_label  = "Consumption-based CO2 per capita (tonnes)")
    }
  })
  
  eff_current <- reactive({
    eff_base_df() %>% filter(Period == selected_period())
  })
  
  output$eff_main_plot <- renderPlotly({
    if (input$eff_view == "ranking")       eff_plot_ranking()
    else if (input$eff_view == "trend")    eff_plot_trend()
    else                                   eff_plot_quadrant()
  })
  
  eff_plot_ranking <- function() {
    df <- eff_current()
    req(nrow(df) > 0)
    n  <- input$eff_top_n
    
    df_top    <- df %>% arrange(desc(efficiency)) %>% slice_head(n = n)
    df_bottom <- df %>% arrange(efficiency)        %>% slice_head(n = n)
    df_vn     <- df %>% filter(Entity == "Vietnam")
    
    df_plot <- bind_rows(df_top, df_bottom, df_vn) %>%
      distinct(Entity, .keep_all = TRUE) %>%
      mutate(highlight = case_when(
        Entity == "Vietnam"                ~ "Vietnam",
        efficiency >= df_top$efficiency[n] ~ "Top (Clean)",
        TRUE                               ~ "Bottom (Dirty)")) %>%
      arrange(desc(efficiency))
    
    color_map <- c("Vietnam"="#e74c3c", "Top (Clean)"="#2ca02c",
                   "Bottom (Dirty)"="#d62728")
    
    p <- ggplot(df_plot, aes(
      x    = reorder(Entity, efficiency),
      y    = efficiency,
      fill = highlight,
      text = paste0("<b>", Entity, "</b><br>",
                    "Carbon Efficiency: $", scales::comma(round(efficiency)),
                    " per tonne<br>",
                    "GDP per capita: $", scales::comma(round(gdp_pc)), "<br>",
                    "CO2 per capita: ", round(emission_col, 2), " t")
    )) +
      geom_col(width = 0.75) +
      geom_hline(yintercept = df_vn$efficiency[1],
                 color="#e74c3c", linewidth=0.8, linetype="dashed") +
      coord_flip() +
      scale_fill_manual(values = color_map) +
      scale_y_continuous(labels = scales::dollar_format()) +
      labs(title    = paste0("Carbon Efficiency Ranking — ", selected_period()),
           subtitle = "GDP generated per tonne of CO2. Higher = more efficient.",
           x="", y="GDP per tonne of CO2 (USD)", fill="",
           caption = "Red dashed line = Vietnam's efficiency level") +
      dark_theme(base_size = 13)
    
    ggplotly(p, tooltip="text") %>% dark_plotly(height=520)
  }
  
  eff_plot_trend <- function() {
    peers <- unique(c("Vietnam", input$eff_peer_countries))
    req(length(peers) >= 1)
    
    df <- eff_base_df() %>%
      filter(Entity %in% peers) %>%
      mutate(Period_label = as.character(Period),
             is_vietnam   = Entity == "Vietnam") %>%
      arrange(Period)
    
    req(nrow(df) > 0)
    req(length(unique(df$Period)) >= 2)
    
    others      <- setdiff(peers, "Vietnam")
    peer_colors <- c("#1f77b4","#2ca02c","#ff7f0e","#9467bd","#8c564b","#17becf")
    color_map   <- setNames(peer_colors[seq_along(others)], others)
    color_map["Vietnam"] <- "#e74c3c"
    
    p <- ggplot(df, aes(x=Period_label, y=efficiency,
                        color=Entity, group=Entity,
                        text=paste0("<b>", Entity, "</b><br>",
                                    "Period: ", Period_label, "<br>",
                                    "Carbon Efficiency: $",
                                    scales::comma(round(efficiency)),
                                    " per tonne<br>",
                                    "GDP per capita: $",
                                    scales::comma(round(gdp_pc)), "<br>",
                                    "CO2 per capita: ",
                                    round(emission_col, 2), " t"))) +
      geom_line(data=filter(df,!is_vietnam), linewidth=1.2, alpha=0.75) +
      geom_point(data=filter(df,!is_vietnam), size=3, alpha=0.75) +
      geom_line(data=filter(df,is_vietnam),  linewidth=2.5, color="#e74c3c") +
      geom_point(data=filter(df,is_vietnam), size=5, color="#e74c3c", shape=18) +
      scale_color_manual(values=color_map) +
      scale_y_continuous(labels=scales::dollar_format()) +
      labs(title    = "Carbon Efficiency Trend Over Time",
           subtitle = "GDP per tonne of CO2 — growing cleaner or dirtier?",
           x="Period", y="GDP per tonne of CO2 (USD)", color="Country",
           caption="Rising = more efficient. Falling = emissions growing faster than GDP.") +
      dark_theme(base_size = 13) +
      theme(axis.text.x = element_text(angle = 45, hjust = 1, colour = "#a8c5b5"))
    
    ggplotly(p, tooltip="text") %>% dark_plotly(height=520)
  }
  
  eff_plot_quadrant <- function() {
    df <- eff_current()
    req(nrow(df) > 0)
    
    med_gdp <- median(df$gdp_pc,    na.rm=TRUE)
    med_eff <- median(df$efficiency, na.rm=TRUE)
    
    df <- df %>%
      mutate(
        quadrant = case_when(
          gdp_pc >= med_gdp & efficiency >= med_eff ~ "Rich & Clean",
          gdp_pc >= med_gdp & efficiency <  med_eff ~ "Rich & Dirty",
          gdp_pc <  med_gdp & efficiency >= med_eff ~ "Poor & Clean",
          TRUE                                       ~ "Poor & Dirty"),
        is_vietnam = Entity == "Vietnam")
    
    color_map <- c("Rich & Clean"="#2ca02c","Rich & Dirty"="#d62728",
                   "Poor & Clean"="#1f77b4","Poor & Dirty"="#ff7f0e")
    
    p <- ggplot() +
      annotate("rect", xmin=-Inf, xmax=med_gdp, ymin=med_eff, ymax=Inf,
               fill="#1f77b4", alpha=0.06) +
      annotate("rect", xmin=med_gdp, xmax=Inf,  ymin=med_eff, ymax=Inf,
               fill="#2ca02c", alpha=0.06) +
      annotate("rect", xmin=-Inf, xmax=med_gdp, ymin=-Inf, ymax=med_eff,
               fill="#ff7f0e", alpha=0.06) +
      annotate("rect", xmin=med_gdp, xmax=Inf,  ymin=-Inf, ymax=med_eff,
               fill="#d62728", alpha=0.06) +
      geom_vline(xintercept=med_gdp, color="#555", linewidth=0.7, linetype="dashed") +
      geom_hline(yintercept=med_eff, color="#555", linewidth=0.7, linetype="dashed") +
      annotate("text", x=med_gdp*0.3, y=med_eff*2.2,
               label="Poor & Clean", color="#1f77b4", size=4, fontface="bold") +
      annotate("text", x=med_gdp*3.5, y=med_eff*2.2,
               label="Rich & Clean", color="#2ca02c", size=4, fontface="bold") +
      annotate("text", x=med_gdp*0.3, y=med_eff*0.4,
               label="Poor & Dirty", color="#ff7f0e", size=4, fontface="bold") +
      annotate("text", x=med_gdp*3.5, y=med_eff*0.4,
               label="Rich & Dirty", color="#d62728", size=4, fontface="bold") +
      geom_point(data=filter(df,!is_vietnam),
                 aes(x=gdp_pc, y=efficiency, color=quadrant, size=emission_col,
                     text=paste0("<b>", Entity, "</b><br>",
                                 "GDP per capita: $",
                                 scales::comma(round(gdp_pc)), "<br>",
                                 "Carbon Efficiency: $",
                                 scales::comma(round(efficiency)),
                                 " per tonne<br>",
                                 "CO2 per capita: ",
                                 round(emission_col,2), " t<br>",
                                 "Quadrant: ", quadrant)),
                 alpha=0.72) +
      geom_point(data=filter(df,is_vietnam),
                 aes(x=gdp_pc, y=efficiency,
                     text=paste0("<b>Vietnam</b><br>",
                                 "GDP per capita: $",
                                 scales::comma(round(gdp_pc)), "<br>",
                                 "Carbon Efficiency: $",
                                 scales::comma(round(efficiency)),
                                 " per tonne<br>",
                                 "Quadrant: ", quadrant)),
                 color="#e74c3c", size=6, shape=18) +
      scale_color_manual(values=color_map) +
      scale_size_continuous(range=c(2,10), guide="none") +
      scale_x_log10(labels=scales::dollar_format()) +
      scale_y_log10(labels=scales::dollar_format()) +
      labs(title    = paste0("Development Quadrant — ", selected_period()),
           subtitle = "Where does each economy sit on wealth vs carbon efficiency?",
           x="GDP per Capita (log scale)",
           y="Carbon Efficiency: GDP per tonne CO2 (log scale)",
           color="Quadrant",
           caption="Dashed lines = global medians. Point size = CO2 per capita.") +
      dark_theme(base_size = 13)
    
    ggplotly(p, tooltip="text") %>% dark_plotly(height=520)
  }
  
  # ── KPI Cards ────────────────────────────────────────────────────────────────
  output$eff_vn_rank <- renderUI({
    df  <- eff_current()
    req(nrow(df) > 0)
    vn  <- df %>% filter(Entity == "Vietnam")
    req(nrow(vn) > 0)
    rk  <- rank(-df$efficiency, ties.method="min")[df$Entity == "Vietnam"]
    tot <- nrow(df)
    pct <- round((1 - rk/tot) * 100, 1)
    tagList(
      tags$p(style="font-size:22px; font-weight:bold; margin:4px 0;",
             paste0("#", rk, " of ", tot)),
      tags$p(style="color:#555; margin:0;",
             paste0("Top ", 100 - pct, "% globally")),
      tags$p(style="color:#555; margin:0;",
             paste0("$", scales::comma(round(vn$efficiency[1])),
                    " GDP / tonne CO2")))
  })
  
  output$eff_most_improved <- renderUI({
    agg_exact <- c("World","Asia","Europe","Africa","North America",
                   "South America","Oceania",
                   "International aviation","International shipping")
    df_all  <- eff_base_df() %>% filter(!Entity %in% agg_exact)
    first_p <- levels(ghg_data$Period)[1]
    last_p  <- selected_period()
    df_f <- df_all %>% filter(Period==first_p) %>% select(Entity, eff_first=efficiency)
    df_l <- df_all %>% filter(Period==last_p)  %>% select(Entity, eff_last=efficiency)
    df_ch <- inner_join(df_f, df_l, by="Entity") %>%
      mutate(pct = ((eff_last - eff_first) / eff_first) * 100) %>%
      arrange(desc(pct)) %>% slice_head(n=3)
    tags$ul(style="padding-left:16px; margin:4px 0;",
            lapply(seq_len(nrow(df_ch)), function(i)
              tags$li(paste0(df_ch$Entity[i], " (+", round(df_ch$pct[i],0), "%)"))))
  })
  
  output$eff_most_deteriorated <- renderUI({
    agg_exact <- c("World","Asia","Europe","Africa","North America",
                   "South America","Oceania",
                   "International aviation","International shipping")
    df_all  <- eff_base_df() %>% filter(!Entity %in% agg_exact)
    first_p <- levels(ghg_data$Period)[1]
    last_p  <- selected_period()
    df_f <- df_all %>% filter(Period==first_p) %>% select(Entity, eff_first=efficiency)
    df_l <- df_all %>% filter(Period==last_p)  %>% select(Entity, eff_last=efficiency)
    df_ch <- inner_join(df_f, df_l, by="Entity") %>%
      mutate(pct = ((eff_last - eff_first) / eff_first) * 100) %>%
      arrange(pct) %>% slice_head(n=3)
    tags$ul(style="padding-left:16px; margin:4px 0;",
            lapply(seq_len(nrow(df_ch)), function(i)
              tags$li(paste0(df_ch$Entity[i], " (", round(df_ch$pct[i],0), "%)"))))
  })
  
  output$eff_vn_trend <- renderUI({
    agg_exact <- c("World","Asia","Europe","Africa","North America",
                   "South America","Oceania",
                   "International aviation","International shipping")
    df_all  <- eff_base_df() %>% filter(!Entity %in% agg_exact)
    first_p <- levels(ghg_data$Period)[1]
    last_p  <- selected_period()
    vn_f <- df_all %>% filter(Entity=="Vietnam", Period==first_p) %>% pull(efficiency)
    vn_l <- df_all %>% filter(Entity=="Vietnam", Period==last_p)  %>% pull(efficiency)
    req(length(vn_f) > 0, length(vn_l) > 0)
    pct    <- round(((vn_l - vn_f) / vn_f) * 100, 1)
    arrow  <- if (pct >= 0) "\u2191" else "\u2193"
    col    <- if (pct >= 0) "#2ca02c" else "#d62728"
    interp <- if (pct >= 0) "Getting cleaner relative to GDP growth"
    else           "Emissions growing faster than GDP"
    tagList(
      tags$p(style=paste0("font-size:20px; font-weight:bold; color:",
                          col, "; margin:4px 0;"),
             paste0(arrow, " ", abs(pct), "% since ", first_p)),
      tags$p(style="color:#555; font-size:12px; margin:0;", interp))
  })
  
  # ── Global Map ───────────────────────────────────────────────────────────────
  output$map_plot <- renderPlotly({
    
    base_df <- ghg_data %>% filter(Period == selected_period())
    
    sector_df <- ghg_sector_long %>%
      filter(Period == selected_period(), Sector == input$sector) %>%
      select(Entity, Sector_Emissions = Emissions)
    
    map_df <- world_map %>%
      left_join(base_df,   by = c("name" = "Entity")) %>%
      left_join(sector_df, by = c("name" = "Entity")) %>%
      mutate(
        fill_value = if (input$metric == "gap") Responsibility_Gap
        else cons_ghg - prod_ghg,
        # Highlight Vietnam with a star marker via hover
        hover_text = paste0(
          "<b>", name, "</b>",
          ifelse(name == "Vietnam", " \u2b50", ""), "<br>",
          "Production GHG: ",     scales::comma(round(prod_ghg/1e6, 1)),          " Mt<br>",
          "Consumption GHG: ",    scales::comma(round(cons_ghg/1e6, 1)),          " Mt<br>",
          "Responsibility Gap: ", scales::comma(round(Responsibility_Gap/1e6, 1))," Mt<br>",
          "Sector Emissions: ",   scales::comma(round(Sector_Emissions/1e6, 1)),  " Mt"
        )
      )
    
    p <- ggplot(map_df, aes(fill = fill_value, text = hover_text)) +
      geom_sf(color = NA) +
      scale_fill_viridis_c(option = "plasma", na.value = "grey90") +
      dark_theme(base_size = 14)
    
    ggplotly(p, tooltip = "text") %>% dark_plotly(height = 600)
  })
}

shinyApp(ui, server)
