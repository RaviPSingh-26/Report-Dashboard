library(readxl)
library(dplyr)
library(writexl)
df1<- annual_co2_emissions_per_country
df2<-annual_share_of_co2_emissions
df3<-co_emissions_per_capita
df4<-consumption_co2_per_capita_vs_gdppc
clean_df <- function(df) {
  df %>%
    rename(
      country = Entity,
      year = Year
    ) %>%
    select(-Code)  
}

df1 <- clean_df(df1)
df2 <- clean_df(df2)
df3 <- clean_df(df3)
df4 <- clean_df(df4)


merged_data <- df1 %>%
  full_join(df2, by = c("country", "year")) %>%
  full_join(df3, by = c("country", "year")) %>%
  full_join(df4, by = c("country", "year"))

head(merged_data)

write_xlsx(merged_data, "merged_co2_data.xlsx")

co2 <- Merged_clean_CO2

co2 <- co2 %>%
  mutate(Period_start = (year %/% 5) * 5)

co2_5yr <- co2 %>%
  group_by(country, Period_start) %>%
  summarise(
    across(
      .cols = where(is.numeric) & !matches("^year$"),
      .fns = ~ mean(.x, na.rm = TRUE)
    ),
    .groups = "drop"
  )

co2_5yr <- co2_5yr %>%
  mutate(
    Period = paste0(Period_start, "-", Period_start + 4)
  )

co2_5yr <- co2_5yr %>%
  select(country, Period, Period_start, everything())

head(co2_5yr)
write_xlsx(co2_5yr, "co2_5yr_format.xlsx")


cn <- co2_5yr_format
ghg <- merged_5yr_mean

names(cn) <- tolower(names(cn))
names(ghg) <- tolower(names(ghg))

merged <- full_join(cn, ghg, by = c("country", "period_start","period"))

if ("code" %in% names(merged)) {
  merged <- merged %>%
    select(country, code, everything())
}

head(merged)

write_xlsx(merged, "final_cleaned_merged_5yr.xlsx")
getwd()
